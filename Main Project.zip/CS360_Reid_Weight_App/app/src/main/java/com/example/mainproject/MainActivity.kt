package com.example.mainproject


import android.content.Context
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun createDeviceProtectedStorageContext(): Context {
        return super.createDeviceProtectedStorageContext()

        TextView username = (TextView) findViewById (R.id.Username);
        TextView password = (TextView) findViewById (R.id.Password);
    }
}